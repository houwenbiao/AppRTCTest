# AppRTCTest

WebRTC项目，更新webRTC库版本为21450；使用之前请将服务器地址更改为自己的服务器。